# Mobleu Visual Agent

Claude Vision + Pletor → generación automática de imágenes de moda.

## Setup local

```bash
# 1. Instalar dependencias
npm install

# 2. Configurar variables de entorno
cp .env.example .env
# Edita .env con tus keys reales

# 3. Encontrar tu agent_id de Pletor
# Corre el servidor y visita: http://localhost:3000/api/pletor/agents
# Busca el agente de Mobleu y copia su ID

# 4. Correr el servidor
npm start
# → http://localhost:3000
```

## Variables de entorno (.env)

| Variable | Descripción |
|----------|-------------|
| `ANTHROPIC_API_KEY` | Tu API key de Anthropic |
| `PLETOR_API_KEY` | Tu API key de Pletor (`X-Api-Key`) |
| `PLETOR_AGENT_ID` | UUID del agente en Pletor |

## ⚠️ Paso crítico: Input IDs del agente Pletor

Cada agente en Pletor tiene inputs con IDs únicos. Debes configurarlos en `public/index.html` en la función `buildPletorInputs()`:

```js
// En public/index.html, busca buildPletorInputs() y reemplaza:
{ id: 'INPUT_PROMPT_ID', value: out.prompt }  // ← ID real del input de texto
{ id: 'INPUT_ASSETS_ID', value: { asset_ids: assetIds } }  // ← ID real del input de imágenes
```

Para encontrar los IDs correctos, visita: `GET /api/pletor/agents/TU_AGENT_ID`  
O en el servidor corriendo: `http://localhost:3000/api/pletor/agents/TU_AGENT_ID`

El response tiene el campo `inputs: [{ id, type, description }]`.

## Flujo completo

```
1. Usuario sube imágenes (escenario + modelo + 1-3 productos)
2. Claude Vision analiza TODAS las imágenes
3. Claude genera prompts específicos para cada output (JSON)
4. App sube las referencias a Pletor /assets/upload
5. Por cada output: POST /runs/ → poll hasta completado → render imagen
6. Usuario descarga resultados
```

## Deploy en Render

1. Push a GitHub (`.env` está en `.gitignore` ✅)
2. En Render: New Web Service → conecta tu repo
3. Build command: `npm install`
4. Start command: `npm start`
5. En Render → Environment → agrega las variables de `.env`

## API Routes del servidor

| Método | Ruta | Descripción |
|--------|------|-------------|
| `POST` | `/api/analyze` | Claude analiza imágenes y genera plan JSON |
| `GET` | `/api/pletor/agents` | Lista agentes de Pletor |
| `GET` | `/api/pletor/agents/:id` | Detalle de un agente (ver input IDs) |
| `POST` | `/api/pletor/upload` | Sube asset a Pletor |
| `POST` | `/api/pletor/run` | Crea run en Pletor |
| `GET` | `/api/pletor/run/:id` | Poll estado del run |
| `GET` | `/api/pletor/asset/:id/download` | Proxy descarga de asset |
| `DELETE` | `/api/pletor/run/:id` | Cancela un run |
| `GET` | `/api/health` | Estado de las APIs |
